﻿using System;
using System.Text;

class Cube
{
    private double edge;

    // Конструктор з параметром
    public Cube(double edge)
    {
        this.edge = edge;
    }

    // Логічний метод Correct
    public bool Correct()
    {
        return edge > 0;
    }

    public double Area()
    {
        return 6 * Math.Pow(edge, 2);
    }

    public double Volume()
    {
        return Math.Pow(edge, 3);
    }

    public void Print()
    {
        Console.WriteLine($"Ребро куба: {edge}");
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        try
        {
            Console.Write("Введіть ребро куба: ");
            double edge = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Cube cube = new Cube(edge);

            cube.Print();

            if (cube.Correct())
            {
                Console.WriteLine($"Площа поверхні куба: {cube.Area()}");

                Console.WriteLine($"Об'єм куба: {cube.Volume()}");
            }
            else
            {
                Console.WriteLine("Куб не може існувати з заданим ребром.");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Сталася помилка. Будь ласка, введіть дійсні дані.");
        }
    }
}
