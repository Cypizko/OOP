﻿using System;
using System.Text;

public class SmartHomeDevice
{
    // Приватні поля
    private string deviceName;
    private string deviceType;
    private bool status;
    private double powerConsumption;
    private double batteryLevel; 

    // Публічні властивості
    public string DeviceName
    {
        get { return deviceName; }
        set { deviceName = value; }
    }

    public string DeviceType
    {
        get { return deviceType; }
        set { deviceType = value; }
    }

    public bool Status
    {
        get { return status; }
        set { status = value; }
    }

    public double PowerConsumption
    {
        get { return powerConsumption; }
        set
        {
            powerConsumption = value;
        }
    }

    public double BatteryLevel
    {
        get { return batteryLevel; }
        set
        {
            batteryLevel = value;
        }
    }

    // Конструктор за замовчуванням
    public SmartHomeDevice()
    {
        deviceName = String.Empty;
        deviceType = String.Empty;
        status = false;
        powerConsumption = 0;
        batteryLevel = -1; // Пристрої без батареї мають -1
    }

    // Параметризований конструктор
    public SmartHomeDevice(string deviceName, string deviceType, bool status, double powerConsumption, double batteryLevel)
    {
        this.deviceName = deviceName;
        this.deviceType = deviceType;
        this.status = status;
        this.powerConsumption = powerConsumption;
        this.batteryLevel = batteryLevel; 
    }

    // Конструктор копіювання
    public SmartHomeDevice(SmartHomeDevice other)
    {
        this.deviceName = other.deviceName;
        this.deviceType = other.deviceType;
        this.status = other.status;
        this.powerConsumption = other.powerConsumption;
        this.batteryLevel = other.batteryLevel;
    }

    // Публічні методи
    public void TurnOn()
    {
        status = true;
    }

    public void TurnOff()
    {
        status = false;
    }

    public bool GetStatus()
    {
        return status;
    }

    public void PrintInfo()
    {
        Console.WriteLine($"Назва пристрою: {deviceName}");
        Console.WriteLine($"Тип пристрою: {deviceType}");
        Console.WriteLine($"Статус: {(status ? "ввімкнений" : "вимкнений")}");
        Console.WriteLine($"Споживання енергії: {powerConsumption} Вт");

        // перевірка, чи пристрій має батарею
        if (batteryLevel != -1)
        {
            Console.WriteLine($"Рівень заряду батареї: {batteryLevel}%");
        }
    }

    public bool BatteryCheck()
    {
        return batteryLevel != -1 && batteryLevel < 20;
    }

    public override string ToString()
    {
        string info = $"Пристрій: {deviceName}, Тип: {deviceType}, Статус: {(status ? "ввімкнений" : "вимкнений")}, Споживання: {powerConsumption} Вт";
        if (batteryLevel != -1)
        {
            info += $", Заряд батареї: {batteryLevel}%";
        }
        return info;
    }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        SmartHomeDevice lamp = new SmartHomeDevice("Лампа", "Система освітлення", false, 60, -1);
        SmartHomeDevice ventilation = new SmartHomeDevice("Вентиляція(Ванна кімната)", "Система вентиляції", true, 150, 50);

        bool exit = false;
        while (!exit)
        {
            Console.Clear(); 

            Console.WriteLine("========================================");
            Console.WriteLine("Меню:");
            Console.WriteLine("1. Вивести інформацію про лампу");
            Console.WriteLine("2. Включити лампу");
            Console.WriteLine("3. Вимкнути лампу");
            Console.WriteLine("4. Вивести інформацію про вентиляцію");
            Console.WriteLine("5. Включити вентиляцію");
            Console.WriteLine("6. Вимкнути вентиляцію");
            Console.WriteLine("7. Перевірити рівень заряду вентиляції");
            Console.WriteLine("8. Вийти");
            Console.WriteLine("========================================");

            Console.Write("Виберіть дію: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Clear();
                    lamp.PrintInfo();
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "2":
                    lamp.TurnOn();
                    Console.Clear();
                    Console.WriteLine("Лампа ввімкнена.");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "3":
                    lamp.TurnOff();
                    Console.Clear();
                    Console.WriteLine("Лампа вимкнена.");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "4":
                    Console.Clear();
                    ventilation.PrintInfo();
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "5":
                    ventilation.TurnOn();
                    Console.Clear();
                    Console.WriteLine("Вентиляцію ввімкнено.");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "6":
                    ventilation.TurnOff();
                    Console.Clear();
                    Console.WriteLine("Вентиляцію вимкнено.");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "7":
                    Console.Clear();
                    Console.WriteLine($"Низький рівень батареї: {ventilation.BatteryCheck()}");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
                case "8":
                    exit = true;
                    break;
                default:
                    Console.Clear();
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    Console.WriteLine("\nНатисніть будь-яку клавішу, щоб повернутися до меню...");
                    Console.ReadKey();
                    break;
            }
        }

        Console.Clear();
        Console.WriteLine("Ви вийшли з програми.");
    }
}
