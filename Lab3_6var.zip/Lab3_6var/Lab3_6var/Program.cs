﻿using System;
using System.Text;

namespace SocialMediaApp
{
    public class UserProfile
    {
        private string username;
        private string email;
        private string status;

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        public UserProfile()
        {
            username = "Anonymous";
            email = "unknown@example.com";
            status = "Active";
        }

        public UserProfile(string username, string email, string status)
        {
            this.username = username;
            this.email = email;
            this.status = status;
        }

        public virtual void SendMessage(string message)
        {
            Console.WriteLine($"{username} відправив повідомлення: {message}.");
        }

        public virtual void DeleteAccount()
        {
            Console.WriteLine($"Профіль {username} видалено.");
        }

        public override string ToString()
        {
            return $"Ім'я користувача: {username}\nЕлектронна адреса: {email}\nСтатус: {status}";
        }
    }

    public class AdminProfile : UserProfile
    {
        private int adminLevel;

        public AdminProfile(string username, string email, string status, int adminLevel)
            : base(username, email, status)
        {
            this.adminLevel = adminLevel;
        }

        public override void SendMessage(string message)
        {
            Console.WriteLine($"Адміністратор {Username} відправив системне повідомлення: {message}.");
        }

        public void BanUser(RegularProfile regularProfile)
        {
            if (regularProfile != null)
            {
                regularProfile.Status = "banned";
                Console.WriteLine($"Адміністратор заблокував користувача {regularProfile.Username}.");
            }
        }

        public void UnbanUser(RegularProfile regularProfile)
        {
            if (regularProfile != null)
            {
                regularProfile.Status = "Active";
                Console.WriteLine($"Адміністратор розблокував користувача {regularProfile.Username}.");
            }
        }

        public override void DeleteAccount()
        {
            Console.WriteLine($"Адміністративний профіль {Username} видалено.");
        }
    }

    public class RegularProfile : UserProfile
    {
        private int friendCount;

        public RegularProfile(string username, string email, string status)
            : base(username, email, status)
        {
            friendCount = 0;
        }

        public override void SendMessage(string message)
        {
            if (Status == "banned")
            {
                Console.WriteLine($"{Username} не може надіслати повідомлення, оскільки його статус заблоковано.");
            }
            else
            {
                Console.WriteLine($"{Username} відправив особисте повідомлення: {message}.");
            }
        }

        public void AddFriend()
        {
            if (Status == "banned")
            {
                Console.WriteLine($"{Username} не може додати друга, оскільки його статус заблоковано.");
            }
            else
            {
                friendCount++;
                Console.WriteLine($"{Username} додав нового друга. Загальна кількість друзів: {friendCount}.");
            }
        }

        public override void DeleteAccount()
        {
            Console.WriteLine($"Звичайний профіль {Username} видалено.");
        }

        public override string ToString()
        {
            return $"Ім'я користувача: {Username}\nЕлектронна адреса: {Email}\nСтатус: {Status}\nКількість друзів: {friendCount}";
        }
    }

    class Program
    {
        static RegularProfile regularProfile = null;
        static AdminProfile adminProfile = null;

        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            bool exit = false;
            bool passwordTry = false;

            while (!exit)
            {

                Console.Clear();
                if (passwordTry == true)
                {
                    Console.WriteLine("Невірний пароль, спробуйте ще раз.");
                }
                Console.WriteLine("Головне меню:");
                Console.WriteLine("1. Меню звичайного користувача");
                Console.WriteLine("2. Меню адміністратора");
                Console.WriteLine("3. Вийти");
                Console.Write("Виберіть дію: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        RegularUserMenu();
                        break;

                    case "2":
                        Console.WriteLine("Введіть пароль: ");
                        string adminPassword = Console.ReadLine();
                        if (adminPassword == "123")
                        {
                            AdminUserMenu();
                            passwordTry = false;
                        }
                        else
                        {
                            passwordTry = true;
                            
                        }
                        break;

                    case "3":
                        exit = true;
                        Console.WriteLine("Вихід з програми...");
                        break;

                    default:
                        Console.WriteLine("Невірний вибір, спробуйте ще раз.");
                        break;
                }
            }
        }

        static void RegularUserMenu()
        {
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("==========================================");
                Console.WriteLine("Меню звичайного користувача:");
                Console.WriteLine("1. Створити звичайний профіль");
                Console.WriteLine("2. Переглянути інформацію про профіль");
                Console.WriteLine("3. Надіслати повідомлення");
                Console.WriteLine("4. Додати друга");
                Console.WriteLine("5. Видалити профіль");
                Console.WriteLine("6. Повернутись до головного меню");
                Console.WriteLine("==========================================");
                Console.Write("Виберіть дію: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        regularProfile = new RegularProfile("RegularUser", "user@example.com", "Active");
                        Console.WriteLine($"Створено звичайний профіль:\n{regularProfile}");
                        break;

                    case "2":
                        Console.Clear();
                        if (regularProfile != null)
                        {
                            Console.WriteLine(regularProfile.ToString());
                        }
                        else
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        break;


                    case "3":
                        if (regularProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        else
                        {
                            Console.Clear();
                            Console.Write("Введіть повідомлення: ");
                            string message = Console.ReadLine();
                            regularProfile.SendMessage(message);
                        }
                        break;

                    case "4":
                        if (regularProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        else
                        {
                            Console.Clear();
                            regularProfile.AddFriend();
                        }
                        break;

                    case "5":
                        if (regularProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        else
                        {
                            Console.Clear();
                            regularProfile.DeleteAccount();
                            regularProfile = null;
                        }
                        break;

                    case "6":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Невірний вибір, спробуйте ще раз.");
                        break;
                }
                Console.ReadKey();
            }
        }

        static void AdminUserMenu()
        {
            bool exit = false;

            while (!exit)
            {
                Console.Clear();
                Console.WriteLine("==========================================");
                Console.WriteLine("Меню адміністратора:");
                Console.WriteLine("1. Створити адміністративний профіль");
                Console.WriteLine("2. Переглянути інформацію про профіль");
                Console.WriteLine("3. Надіслати системне повідомлення");
                Console.WriteLine("4. Заблокувати користувача");
                Console.WriteLine("5. Розблокувати користувача");
                Console.WriteLine("6. Видалити профіль");
                Console.WriteLine("7. Повернутись до головного меню");
                Console.WriteLine("==========================================");
                Console.Write("Виберіть дію: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        adminProfile = new AdminProfile("AdminUser", "admin@example.com", "Active", 1);
                        Console.WriteLine($"Створено адміністративний профіль:\n{adminProfile}");
                        break;

                    case "2":
                        Console.Clear();
                        if (adminProfile != null)
                        {
                            Console.WriteLine(adminProfile.ToString());
                        }
                        else
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        break;



                    case "3":
                        if (adminProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        else
                        {
                            Console.Clear();
                            Console.Write("Введіть системне повідомлення: ");
                            string message = Console.ReadLine();
                            adminProfile.SendMessage(message);
                        }
                        break;

                    case "4":
                        if (adminProfile == null || regularProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль адміністратора та звичайного користувача.");
                        }
                        else
                        {
                            Console.Clear();
                            adminProfile.BanUser(regularProfile);
                        }
                        break;

                    case "5":
                        if (adminProfile == null || regularProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль адміністратора та звичайного користувача.");
                        }
                        else
                        {
                            Console.Clear();
                            adminProfile.UnbanUser(regularProfile);
                        }
                        break;

                    case "6":
                        if (adminProfile == null)
                        {
                            Console.WriteLine("Спочатку потрібно створити профіль.");
                        }
                        else
                        {
                            Console.Clear();
                            adminProfile.DeleteAccount();
                            adminProfile = null;
                        }
                        break;

                    case "7":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("Невірний вибір, спробуйте ще раз.");
                        break;
                }
                Console.ReadKey();

            }
        }
    }
}

