﻿using System;
using System.Text;

namespace RecipeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            while (true)
            {
                int choice = 0;
                bool validInput = false;

                // меню вибору типу рецепту з обробкою некоректних даних
                while (!validInput)
                {
                    ClearConsole();
                    Console.WriteLine("Оберіть тип рецепту:");
                    Console.WriteLine("1 - Салат");
                    Console.WriteLine("2 - Суп");
                    Console.WriteLine("3 - Десерт");
                    Console.WriteLine("4 - Напій");
                    Console.WriteLine("------------------------------");
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out choice) && choice >= 1 && choice <= 4)
                    {
                        validInput = true;
                    }
                    else
                    {
                        Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    }
                }

                Recipe recipe = null;

                switch (choice)
                {
                    case 1:
                        recipe = new Salad();
                        break;
                    case 2:
                        recipe = new Soup();
                        break;
                    case 3:
                        recipe = new Dessert();
                        break;
                    case 4:
                        recipe = new Drink();
                        break;
                }

                validInput = false;

                // вибір використання стандартних інгредієнтів або введення власних
                while (!validInput)
                {
                    ClearConsole();
                    Console.WriteLine("Оберіть режим:");
                    Console.WriteLine("1 - Використовувати стандартні інгредієнти");
                    Console.WriteLine("2 - Ввести власні інгредієнти");
                    Console.WriteLine("------------------------------");
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out int mode) && (mode == 1 || mode == 2))
                    {
                        validInput = true;

                        if (mode == 1)
                        {
                            recipe.UseDefaultIngredients();
                        }
                        else if (mode == 2)
                        {
                            recipe.EnterIngredients();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    }
                }

                ClearConsole();
                recipe.Cook();

                validInput = false;

                // вибір методу розрахунку часу приготування
                while (!validInput)
                {
                    ClearConsole();
                    Console.WriteLine("Оберіть метод розрахунку часу:");
                    Console.WriteLine("1 - На основі кількості інгредієнтів");
                    Console.WriteLine("2 - На основі кількості інгредієнтів та складності");
                    Console.WriteLine("------------------------------");
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out int timeChoice) && (timeChoice == 1 || timeChoice == 2))
                    {
                        validInput = true;

                        if (timeChoice == 1)
                        {
                            Console.WriteLine($"Час приготування: {recipe.CalculateCookingTime(recipe.IngredientCount)} хвилин");
                        }
                        else if (timeChoice == 2)
                        {
                            Console.WriteLine("Введіть складність (1-5):");
                            int difficulty = int.Parse(Console.ReadLine());
                            Console.WriteLine($"Час приготування: {recipe.CalculateCookingTime(recipe.IngredientCount, difficulty)} хвилин");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    }
                }

                Console.WriteLine("------------------------------");
                Console.WriteLine("Бажаєте приготувати ще щось? (y/n)");
                if (Console.ReadLine().ToLower() != "y") break;
            }
        }

        static void ClearConsole()
        {
            Console.Clear();
            Console.WriteLine("------------------------------");
        }
    }

    class Recipe
    {
        public string[] Ingredients { get; set; }
        public int IngredientCount { get; set; }

        public virtual void Cook()
        {
            Console.WriteLine("Приготування...");
        }

        public virtual void UseDefaultIngredients()
        {
            Console.WriteLine("Використано інгредієнти за замовчанням.");
        }

        public void EnterIngredients()
        {
            Console.WriteLine("Скільки інгредієнтів?");
            IngredientCount = int.Parse(Console.ReadLine());
            if (IngredientCount <= 0)
            {
                Console.WriteLine("Кількість інгредієнтів повинна бути більше 0.");
                return;
            }
            Ingredients = new string[IngredientCount];

            for (int i = 0; i < IngredientCount; i++)
            {
                Console.WriteLine($"Введіть інгредієнт {i + 1}:");
                Ingredients[i] = Console.ReadLine();
            }
        }

        public int CalculateCookingTime(int ingredientsCount)
        {
            return ingredientsCount * 5; //5 хв на інгредієнт
        }

        public int CalculateCookingTime(int ingredientsCount, int difficulty)
        {
            return ingredientsCount * 5 + difficulty * 10; // складність додає додатковий час
        }
    }

    class Salad : Recipe
    {
        public override void Cook()
        {
            Console.WriteLine("Нарізання та змішування інгредієнтів для салату...");
        }

        public override void UseDefaultIngredients()
        {
            Ingredients = new string[] { "Огірки", "Помідори", "Олія" };
            IngredientCount = Ingredients.Length;
            Console.WriteLine("Використано стандартні інгредієнти для салату: Огірки, Помідори, Олія.");
        }
    }

    class Soup : Recipe
    {
        public override void Cook()
        {
            Console.WriteLine("Варіння інгредієнтів для супу...");
        }

        public override void UseDefaultIngredients()
        {
            Ingredients = new string[] { "Картопля", "Морква", "М'ясо" };
            IngredientCount = Ingredients.Length;
            Console.WriteLine("Використано стандартні інгредієнти для супу: Картопля, Морква, М'ясо.");
        }
    }

    class Dessert : Recipe
    {
        public override void Cook()
        {
            Console.WriteLine("Випікання або охолодження інгредієнтів для десерту...");
        }

        public override void UseDefaultIngredients()
        {
            Ingredients = new string[] { "Борошно", "Цукор", "Яйця" };
            IngredientCount = Ingredients.Length;
            Console.WriteLine("Використано стандартні інгредієнти для десерту: Борошно, Цукор, Яйця.");
        }
    }

    class Drink : Recipe
    {
        public override void Cook()
        {
            Console.WriteLine("Змішування інгредієнтів для напою...");
        }

        public override void UseDefaultIngredients()
        {
            Ingredients = new string[] { "Вода", "Лимон", "Цукор" };
            IngredientCount = Ingredients.Length;
            Console.WriteLine("Використано стандартні інгредієнти для напою: Вода, Лимон, Цукор.");
        }
    }
}
