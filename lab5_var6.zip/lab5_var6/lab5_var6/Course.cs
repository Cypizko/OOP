﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_var6
{
    public abstract class Course
    {
        public string Title { get; set; }
        public string Instructor { get; set; }
        public int Duration { get; set; } // Тривалість у годинах
        public bool IsCompleted { get; set; } // Чи пройшов користувач курс

        public abstract string GetCourseType();

        public void DisplayInfo()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine($"Тип курсу: {GetCourseType()}");
            Console.WriteLine($"Назва: {Title}");
            Console.WriteLine($"Викладач: {Instructor}");
            Console.WriteLine($"Тривалість: {Duration} годин");
            Console.WriteLine(IsCompleted ? "Статус: Курс пройдено" : "Статус: Курс не пройдено");
        }
    }
}
