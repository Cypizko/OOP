﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab5_var6
{
    class CourseManagementSystem
    {
        private List<Course> courses = new List<Course>();

        // Метод для додавання курсу
        public void AddCourse(Course course)
        {
            courses.Add(course);
        }

        // Метод для видалення курсу
        public void DeleteCourse(int index)
        {
            if (index >= 0 && index < courses.Count)
            {
                courses.RemoveAt(index);
                Console.WriteLine("Курс видалено.");
            }
            else
            {
                Console.WriteLine("Невірний індекс курсу.");
            }
        }

        // Метод для відображення всіх курсів
        public void DisplayCourses()
        {
            Console.OutputEncoding = Encoding.UTF8;
            if (courses.Count == 0)
            {
                Console.WriteLine("Курси відсутні.");
            }
            else
            {
                for (int i = 0; i < courses.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {courses[i].Title}");
                }
            }
        }

        // Метод для відображення детальної інформації про курс за номером
        public void DisplayCourseDetails(int index)
        {
            if (index < 0 || index >= courses.Count)
            {
                Console.WriteLine("Невірний індекс курсу.");
            }
            else
            {
                courses[index].DisplayInfo();
            }
        }

        // Проходження курсу
        public void TakeCourse(int index)
        {
            if (index < 0 || index >= courses.Count)
            {
                Console.WriteLine("Невірний індекс курсу.");
            }
            else if (courses[index] is IWatchable watchable)
            {
                watchable.Watch();
            }
            else if (courses[index] is IReadable readable)
            {
                readable.Read();
            }
        }

        // Збереження курсів у файл XML
        public void SaveCourses(string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Course>), new Type[] { typeof(VideoCourse), typeof(TextCourse) });
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(fs, courses);
            }
            Console.WriteLine($"\nКурси збережено у файл: {filePath}");
        }

        // Завантаження курсів з файлу XML
        public void LoadCourses(string filePath)
        {
            if (File.Exists(filePath))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(List<Course>), new Type[] { typeof(VideoCourse), typeof(TextCourse) });
                using (FileStream fs = new FileStream(filePath, FileMode.Open))
                {
                    courses = (List<Course>)serializer.Deserialize(fs);
                }
                Console.WriteLine("\nКурси завантажено із файлу.");
            }
            else
            {
                Console.WriteLine("Файл не знайдено.");
            }
        }
    }
}
