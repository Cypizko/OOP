﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using lab5_var6;

class Program
{
    static void Main(string[] args)
    {
        // Встановлення кодування UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        CourseManagementSystem cms = new CourseManagementSystem();

        string filePath = "courses.xml";
        cms.LoadCourses(filePath); // Автоматичне завантаження курсів

        while (true)
        {
            Console.Clear();
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Головне меню:");
            Console.WriteLine("1. Переглянути список курсів");
            Console.WriteLine("2. Пройти курс");
            Console.WriteLine("3. Вивести детальну інформацію про курс");
            Console.WriteLine("4. Робота з курсами");
            Console.WriteLine("5. Вийти");
            Console.WriteLine("--------------------------------");
            Console.Write("Виберіть дію: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    cms.DisplayCourses(); // Перегляд списку курсів
                    break;
                case "2":
                    Console.Write("\nВведіть номер курсу для проходження: ");
                    if (int.TryParse(Console.ReadLine(), out int courseToTakeIndex))
                    {
                        cms.TakeCourse(courseToTakeIndex - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "3":
                    Console.Write("\nВведіть номер курсу для перегляду інформації: ");
                    if (int.TryParse(Console.ReadLine(), out int courseIndex))
                    {
                        cms.DisplayCourseDetails(courseIndex - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "4":
                    CoursesManagementMenu(cms, filePath);
                    break;
                case "5":
                    Console.WriteLine("Вихід із програми.");
                    return;
                default:
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
            Console.WriteLine("Нажміть Enter, щоб продовжити...");
            Console.ReadLine();
        }
    }

    static void CoursesManagementMenu(CourseManagementSystem cms, string filePath)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Меню управління курсами:");
            Console.WriteLine("1. Додати новий курс");
            Console.WriteLine("2. Видалити курс");
            Console.WriteLine("3. Зберегти курси у файл");
            Console.WriteLine("4. Завантажити курси з файлу");
            Console.WriteLine("5. Повернутися в головне меню");
            Console.WriteLine("--------------------------------");
            Console.Write("Виберіть дію: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddCourseMenu(cms);
                    break;
                case "2":
                    Console.Write("\nВведіть номер курсу для видалення: ");
                    if (int.TryParse(Console.ReadLine(), out int courseIndexToDelete))
                    {
                        cms.DeleteCourse(courseIndexToDelete - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "3":
                    cms.SaveCourses(filePath);
                    break;
                case "4":
                    cms.LoadCourses(filePath);
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
            Console.WriteLine("Нажміть Enter, щоб продовжити...");
            Console.ReadLine(); // Очікування на натискання клавіші Enter
        }
    }

    static void AddCourseMenu(CourseManagementSystem cms)
    {
        Console.Clear();
        Console.WriteLine("--------------------------------");
        Console.WriteLine("Додати новий курс:");
        Console.WriteLine("1. Відеокурс");
        Console.WriteLine("2. Текстовий курс");
        Console.WriteLine("--------------------------------");
        Console.Write("Виберіть тип курсу: ");
        string typeChoice = Console.ReadLine();

        Console.Write("Введіть назву курсу: ");
        string title = Console.ReadLine();
        Console.Write("Введіть викладача курсу: ");
        string instructor = Console.ReadLine();
        Console.Write("Введіть тривалість курсу в годинах: ");

        if (int.TryParse(Console.ReadLine(), out int duration))
        {
            switch (typeChoice)
            {
                case "1":
                    cms.AddCourse(new VideoCourse { Title = title, Instructor = instructor, Duration = duration });
                    Console.WriteLine("Відеокурс додано.");
                    break;
                case "2":
                    cms.AddCourse(new TextCourse { Title = title, Instructor = instructor, Duration = duration });
                    Console.WriteLine("Текстовий курс додано.");
                    break;
                default:
                    Console.WriteLine("Невірний вибір типу курсу.");
                    break;
            }
        }
        else
        {
            Console.WriteLine("Невірний формат тривалості. Спробуйте ще раз.");
        }
    }
}
