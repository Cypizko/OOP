﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Text;

// Абстрактний клас Course
public abstract class Course
{
    public string Title { get; set; }
    public string Instructor { get; set; }
    public int Duration { get; set; } // Тривалість у годинах
    public bool IsCompleted { get; set; } // Чи пройшов користувач курс

    public abstract string GetCourseType();

    public void DisplayInfo()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine($"Тип курсу: {GetCourseType()}");
        Console.WriteLine($"Назва: {Title}");
        Console.WriteLine($"Викладач: {Instructor}");
        Console.WriteLine($"Тривалість: {Duration} годин");
        Console.WriteLine(IsCompleted ? "Статус: Курс пройдено" : "Статус: Курс не пройдено");
    }
}

public interface IWatchable
{
    void Watch();
}

public interface IReadable
{
    void Read();
}

// Клас-нащадок для відеокурсів
public class VideoCourse : Course, IWatchable
{
    public override string GetCourseType() => "Відеокурс";

    public void Watch()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine($"Ви дивитесь відеокурс \"{Title}\".");
        IsCompleted = true;
    }
}

// Клас-нащадок для текстових курсів
public class TextCourse : Course, IReadable
{
    public override string GetCourseType() => "Текстовий курс";

    public void Read()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.WriteLine($"Ви читаєте текстовий курс \"{Title}\".");
        IsCompleted = true;
    }
}

class CourseManagementSystem
{
    private List<Course> courses = new List<Course>();

    // Метод для додавання курсу
    public void AddCourse(Course course)
    {
        courses.Add(course);
    }

    // Метод для видалення курсу
    public void DeleteCourse(int index)
    {
        if (index >= 0 && index < courses.Count)
        {
            courses.RemoveAt(index);
            Console.WriteLine("Курс видалено.");
        }
        else
        {
            Console.WriteLine("Невірний індекс курсу.");
        }
    }

    // Метод для відображення всіх курсів
    public void DisplayCourses()
    {
        Console.OutputEncoding = Encoding.UTF8;
        if (courses.Count == 0)
        {
            Console.WriteLine("Курси відсутні.");
        }
        else
        {
            for (int i = 0; i < courses.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {courses[i].Title}");
            }
        }
    }

    // Метод для відображення детальної інформації про курс за номером
    public void DisplayCourseDetails(int index)
    {
        if (index < 0 || index >= courses.Count)
        {
            Console.WriteLine("Невірний індекс курсу.");
        }
        else
        {
            courses[index].DisplayInfo();
        }
    }

    // Проходження курсу
    public void TakeCourse(int index)
    {
        if (index < 0 || index >= courses.Count)
        {
            Console.WriteLine("Невірний індекс курсу.");
        }
        else if (courses[index] is IWatchable watchable)
        {
            watchable.Watch();
        }
        else if (courses[index] is IReadable readable)
        {
            readable.Read();
        }
    }

    // Збереження курсів у файл XML
    public void SaveCourses(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(List<Course>), new Type[] { typeof(VideoCourse), typeof(TextCourse) });
        using (FileStream fs = new FileStream(filePath, FileMode.Create))
        {
            serializer.Serialize(fs, courses);
        }
        Console.WriteLine($"\nКурси збережено у файл: {filePath}");
    }

    // Завантаження курсів з файлу XML
    public void LoadCourses(string filePath)
    {
        if (File.Exists(filePath))
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Course>), new Type[] { typeof(VideoCourse), typeof(TextCourse) });
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            {
                courses = (List<Course>)serializer.Deserialize(fs);
            }
            Console.WriteLine("\nКурси завантажено із файлу.");
        }
        else
        {
            Console.WriteLine("Файл не знайдено.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Встановлення кодування UTF-8
        Console.OutputEncoding = Encoding.UTF8;

        CourseManagementSystem cms = new CourseManagementSystem();

        string filePath = "courses.xml";
        cms.LoadCourses(filePath); // Автоматичне завантаження курсів

        while (true)
        {
            Console.Clear();
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Головне меню:");
            Console.WriteLine("1. Переглянути список курсів");
            Console.WriteLine("2. Пройти курс");
            Console.WriteLine("3. Вивести детальну інформацію про курс");
            Console.WriteLine("4. Робота з курсами");
            Console.WriteLine("5. Вийти");
            Console.WriteLine("--------------------------------");
            Console.Write("Виберіть дію: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    cms.DisplayCourses(); // Перегляд списку курсів
                    break;
                case "2":
                    Console.Write("\nВведіть номер курсу для проходження: ");
                    if (int.TryParse(Console.ReadLine(), out int courseToTakeIndex))
                    {
                        cms.TakeCourse(courseToTakeIndex - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "3":
                    Console.Write("\nВведіть номер курсу для перегляду інформації: ");
                    if (int.TryParse(Console.ReadLine(), out int courseIndex))
                    {
                        cms.DisplayCourseDetails(courseIndex - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "4":
                    CoursesManagementMenu(cms, filePath);
                    break;
                case "5":
                    Console.WriteLine("Вихід із програми.");
                    return;
                default:
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
            Console.WriteLine("Нажміть Enter, щоб продовжити...");
            Console.ReadLine();
        }
    }

    static void CoursesManagementMenu(CourseManagementSystem cms, string filePath)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("--------------------------------");
            Console.WriteLine("Меню управління курсами:");
            Console.WriteLine("1. Додати новий курс");
            Console.WriteLine("2. Видалити курс");
            Console.WriteLine("3. Зберегти курси у файл");
            Console.WriteLine("4. Завантажити курси з файлу");
            Console.WriteLine("5. Повернутися в головне меню");
            Console.WriteLine("--------------------------------");
            Console.Write("Виберіть дію: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddCourseMenu(cms);
                    break;
                case "2":
                    Console.Write("\nВведіть номер курсу для видалення: ");
                    if (int.TryParse(Console.ReadLine(), out int courseIndexToDelete))
                    {
                        cms.DeleteCourse(courseIndexToDelete - 1);
                    }
                    else
                    {
                        Console.WriteLine("Невірне значення. Спробуйте ще раз.");
                    }
                    break;
                case "3":
                    cms.SaveCourses(filePath);
                    break;
                case "4":
                    cms.LoadCourses(filePath);
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
            Console.WriteLine("Нажміть Enter, щоб продовжити...");
            Console.ReadLine(); // Очікування на натискання клавіші Enter
        }
    }

    static void AddCourseMenu(CourseManagementSystem cms)
    {
        Console.Clear();
        Console.WriteLine("--------------------------------");
        Console.WriteLine("Додати новий курс:");
        Console.WriteLine("1. Відеокурс");
        Console.WriteLine("2. Текстовий курс");
        Console.WriteLine("--------------------------------");
        Console.Write("Виберіть тип курсу: ");
        string typeChoice = Console.ReadLine();

        Console.Write("Введіть назву курсу: ");
        string title = Console.ReadLine();
        Console.Write("Введіть викладача курсу: ");
        string instructor = Console.ReadLine();
        Console.Write("Введіть тривалість курсу в годинах: ");

        if (int.TryParse(Console.ReadLine(), out int duration))
        {
            switch (typeChoice)
            {
                case "1":
                    cms.AddCourse(new VideoCourse { Title = title, Instructor = instructor, Duration = duration });
                    Console.WriteLine("Відеокурс додано.");
                    break;
                case "2":
                    cms.AddCourse(new TextCourse { Title = title, Instructor = instructor, Duration = duration });
                    Console.WriteLine("Текстовий курс додано.");
                    break;
                default:
                    Console.WriteLine("Невірний вибір типу курсу.");
                    break;
            }
        }
        else
        {
            Console.WriteLine("Невірний формат тривалості. Спробуйте ще раз.");
        }
    }
}
