﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_var6
{
    public class TextCourse : Course, IReadable
    {
        public override string GetCourseType() => "Текстовий курс";

        public void Read()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine($"Ви читаєте текстовий курс \"{Title}\".");
            IsCompleted = true;
        }
    }
}
