﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5_var6
{
    public class VideoCourse : Course, IWatchable
    {
        public override string GetCourseType() => "Відеокурс";

        public void Watch()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine($"Ви дивитесь відеокурс \"{Title}\".");
            IsCompleted = true;
        }
    }
}
