﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

public abstract class Order
{
    public string ClientName { get; }
    public string Destination { get; }
    public bool IsVIP { get; }

    public Order(string clientName, string destination, bool isVIP = false)
    {
        ClientName = clientName;
        Destination = destination;
        IsVIP = isVIP;
    }

    public abstract void Serve();
}

public class RegularOrder : Order
{
    public RegularOrder(string clientName, string destination) : base(clientName, destination) { }

    public override void Serve()
    {
        Console.WriteLine($"Клієнту {ClientName} прийшло повідомлення: \"Ваш водій прибуде через декілька хвилин\"");
        Console.WriteLine($"Замовлення для {ClientName} до {Destination} обслуговується.");
    }
}

public class VIPOrder : Order
{
    public VIPOrder(string clientName, string destination) : base(clientName, destination, true) { }

    public override void Serve()
    {
        Console.WriteLine($"Клієнту {ClientName} прийшло повідомлення: \"Ваш водій прибуде через декілька хвилин\"");
        Console.WriteLine($"VIP замовлення для {ClientName} до {Destination} обслуговується.");
    }
}

public class Driver
{
    public string Name { get; }
    public bool IsAvailable { get; private set; } = true;

    public Driver(string name)
    {
        Name = name;
    }

    public void AssignOrder(Order order)
    {
        IsAvailable = false;
        Console.WriteLine($"{Name} отримав нове замовлення до {order.Destination}.");
    }

    public void CompleteOrder()
    {
        IsAvailable = true;
        Console.WriteLine($"{Name} завершив поїздку.");
    }
}

public class TaxiService
{
    private Queue<Driver> availableDrivers = new Queue<Driver>();
    private List<Order> pendingOrders = new List<Order>();
    private Dictionary<Driver, Order> activeTrips = new Dictionary<Driver, Order>();
    private int completedTrips = 0;

    public event Action<Driver, Order> OnOrderAssigned;

    public IEnumerable<Driver> AvailableDrivers => availableDrivers;
    public IEnumerable<Order> PendingOrders => pendingOrders;
    public Dictionary<Driver, Order> ActiveTrips => activeTrips;

    public void AddOrder(Order order)
    {
        if (availableDrivers.Count > 0)
        {
            var driver = availableDrivers.Dequeue();
            activeTrips[driver] = order;
            OnOrderAssigned?.Invoke(driver, order);
        }
        else
        {
            pendingOrders.Add(order);
            Console.WriteLine("Всі водії зайняті. Замовлення додано до черги очікування.");
        }
    }

    public void AddDriver(Driver driver)
    {
        availableDrivers.Enqueue(driver);
    }

    public void CompleteOrder(Driver driver)
    {
        if (activeTrips.ContainsKey(driver))
        {
            driver.CompleteOrder();
            activeTrips.Remove(driver);
            availableDrivers.Enqueue(driver);
            completedTrips++;
            Console.WriteLine($"Завершено поїздку. Кількість завершених поїздок: {completedTrips}");
            AssignPendingOrders();
        }
    }

    public void ShowDrivers()
    {
        if (availableDrivers.Count == 0 && activeTrips.Count == 0)
        {
            Console.WriteLine("Наразі немає водіїв.");
            return;
        }

        Console.WriteLine("Список водіїв:");
        foreach (var driver in availableDrivers)
        {
            Console.WriteLine($"Водій {driver.Name} - Вільний");
        }

        foreach (var driver in activeTrips.Keys)
        {
            Console.WriteLine($"Водій {driver.Name} - Зайнятий (на поїздці до {activeTrips[driver].Destination})");
        }
    }

    public void ShowPendingOrders()
    {
        if (pendingOrders.Count == 0)
        {
            Console.WriteLine("Наразі немає замовлень.");
            return;
        }

        Console.WriteLine("Список замовлень:");
        foreach (var order in pendingOrders)
        {
            Console.WriteLine($"Замовлення для {order.ClientName} до {order.Destination} (VIP: {order.IsVIP})");
        }
    }

    public void ShowActiveTrips()
    {
        if (activeTrips.Count == 0)
        {
            Console.WriteLine("Наразі немає активних поїздок.");
            return;
        }

        Console.WriteLine("Список активних поїздок:");
        foreach (var trip in activeTrips)
        {
            Console.WriteLine($"Водій {trip.Key.Name} везе клієнта {trip.Value.ClientName} до {trip.Value.Destination} (VIP: {trip.Value.IsVIP})");
        }
    }

    public void ShowStatistics()
    {
        Console.WriteLine($"Кількість завершених поїздок: {completedTrips}");
    }

    public void AssignPendingOrders()
    {
        while (availableDrivers.Count > 0 && pendingOrders.Count > 0)
        {
            pendingOrders = pendingOrders.OrderByDescending(o => o.IsVIP).ToList();
            var nextOrder = pendingOrders[0];
            pendingOrders.RemoveAt(0);

            var driver = availableDrivers.Dequeue();
            activeTrips[driver] = nextOrder;
            OnOrderAssigned?.Invoke(driver, nextOrder);
        }
    }
}

public class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        var taxiService = new TaxiService();
        taxiService.OnOrderAssigned += (driver, order) =>
        {
            driver.AssignOrder(order);
            order.Serve();
        };

        bool running = true;
        while (running)
        {
            Console.Clear();
            Console.WriteLine("Меню:");
            Console.WriteLine("-----------------------");
            Console.WriteLine("1. Додати нового водія");
            Console.WriteLine("2. Додати нове замовлення");
            Console.WriteLine("3. Завершити поїздку для водія");
            Console.WriteLine("4. Показати список водіїв");
            Console.WriteLine("5. Показати список замовлень");
            Console.WriteLine("6. Показати список активних поїздок");
            Console.WriteLine("7. Показати статистику завершених поїздок");
            Console.WriteLine("8. Завершити роботу системи");
            Console.WriteLine("-----------------------");
            Console.Write("Виберіть дію: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Clear();
                    Console.Write("Введіть ім'я водія: ");
                    string driverName = Console.ReadLine();
                    var driver = new Driver(driverName);
                    taxiService.AddDriver(driver);
                    Console.WriteLine($"Водія {driverName} додано в чергу.");
                    taxiService.AssignPendingOrders();
                    break;

                case "2":
                    Console.Clear();
                    Console.Write("Введіть ім'я клієнта: ");
                    string clientName = Console.ReadLine();
                    Console.Write("Введіть місце призначення: ");
                    string destination = Console.ReadLine();

                    bool isVIP;
                    while (true)
                    {
                        Console.Write("Чи є клієнт VIP? (y/n): ");
                        string vipStatus = Console.ReadLine().ToLower();
                        if (vipStatus == "y")
                        {
                            isVIP = true;
                            break;
                        }
                        else if (vipStatus == "n")
                        {
                            isVIP = false;
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Некоректний вибір. Введіть 'y' або 'n'.");
                        }
                    }

                    Order order = isVIP ? new VIPOrder(clientName, destination) : new RegularOrder(clientName, destination);
                    taxiService.AddOrder(order);
                    taxiService.AssignPendingOrders();
                    break;

                case "3":
                    Console.Clear();
                    Console.WriteLine("Оберіть водія для завершення поїздки:");
                    var activeDrivers = taxiService.ActiveTrips.Keys.ToList();
                    for (int i = 0; i < activeDrivers.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {activeDrivers[i].Name} (везе клієнта до {taxiService.ActiveTrips[activeDrivers[i]].Destination})");
                    }
                    Console.Write("Ваш вибір: ");
                    if (int.TryParse(Console.ReadLine(), out int selectedDriverIndex) && selectedDriverIndex > 0 && selectedDriverIndex <= activeDrivers.Count)
                    {
                        taxiService.CompleteOrder(activeDrivers[selectedDriverIndex - 1]);
                    }
                    else
                    {
                        Console.WriteLine("Невірний вибір.");
                    }
                    break;

                case "4":
                    Console.Clear();
                    taxiService.ShowDrivers();
                    break;

                case "5":
                    Console.Clear();
                    taxiService.ShowPendingOrders();
                    break;

                case "6":
                    Console.Clear();
                    taxiService.ShowActiveTrips();
                    break;

                case "7":
                    Console.Clear();
                    taxiService.ShowStatistics();
                    break;

                case "8":
                    running = false;
                    Console.Clear();
                    Console.WriteLine("Завершення роботи системи.");
                    break;

                default:
                    Console.Clear();
                    Console.WriteLine("Невірний вибір. Спробуйте ще раз.");
                    break;
            }
            Console.WriteLine("\nНатисніть Enter для продовження...");
            Console.ReadLine();
        }
    }
}
